import { useEffect, useState } from "react";
import API from "../services/api";
import ExpenseForm from "../components/ExpenseForm";
import ExpenseList from "../components/ExpenseList";

function Dashboard() {
    const [expenses, setExpenses] = useState([]);

    const fetchExpenses = async () => {
        try {
            const response = await API.get("/expenses/1"); // temporary user id
            setExpenses(response.data);
        } catch (error) {
            console.error("Error fetching expenses", error);
        }
    };

    useEffect(() => {
        fetchExpenses();
    }, []);

    return (
        <div className="container">
            <div className="dashboard-header">
                <h2>My Dashboard</h2>
                <button className="secondary" style={{ width: 'auto' }} onClick={() => window.location.href = '/'}>
                    Logout
                </button>
            </div>

            <div className="card">
                <h3>Add New Expense</h3>
                <ExpenseForm refresh={fetchExpenses} />
            </div>

            <div className="card">
                <ExpenseList expenses={expenses} />
            </div>
        </div>
    );
}

export default Dashboard;
