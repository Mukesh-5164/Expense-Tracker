function ExpenseList({ expenses }) {
    return (
        <div className="expense-list">
            {expenses.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: '1rem' }}>No expenses yet. Add one above!</p>
            ) : (
                expenses.map((exp) => (
                    <div key={exp.id || Math.random()} className="expense-item">
                        <span className="expense-title">{exp.title}</span>
                        <span className="expense-amount">₹{exp.amount}</span>
                    </div>
                ))
            )}
        </div>
    );
}

export default ExpenseList;
