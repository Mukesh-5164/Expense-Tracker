import { useState } from "react";
import API from "../services/api";

function ExpenseForm({ refresh }) {
    const [title, setTitle] = useState("");
    const [amount, setAmount] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            await API.post("/expenses", {
                title,
                amount,
                category: "General",
                date: new Date().toISOString().split("T")[0],
            });
            refresh();
            setTitle("");
            setAmount("");
        } catch (error) {
            console.error("Failed to add expense", error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div className="form-group">
                <input
                    placeholder="Title (e.g., Groceries)"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                />
            </div>
            <div className="form-group">
                <input
                    placeholder="Amount (₹)"
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    required
                    min="1"
                />
            </div>
            <button type="submit">Add Expense</button>
        </form>
    );
}

export default ExpenseForm;
